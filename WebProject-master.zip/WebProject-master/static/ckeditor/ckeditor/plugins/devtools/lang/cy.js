﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","cy",{title:"Gwybodaeth am yr Elfen",dialogName:"Enw ffenestr y deialog",tabName:"Enw'r tab",elementId:"ID yr Elfen",elementType:"Math yr elfen"});